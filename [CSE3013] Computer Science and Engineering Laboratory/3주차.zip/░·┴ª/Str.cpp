#include "Str.h"
#include <cstring>
#include <iostream>
using namespace std;
Str::Str(int leng){//leng으로 string의 길이를 정의한 다음, 공백 문자열 만들기 
if(leng<0){
cout<<"Error!\n";
len=0;}
str = new char[leng]; //str에 메모리 할당
for(int i=0;i<leng;i++){
str[i]=' ';
}
}

Str::Str(char *neyong){//neyong에 초기화할 내용 넣기
len =strlen(neyong);
str=new char[len];
strcpy(str,neyong);
}


Str::~Str(){
delete []str; //소멸자
}

int Str::length(void){ //string의 길이 리턴
return len;
}
char *Str::contents(void){ //string의 내용 리턴
return str;
}
int Str::compare(class Str &a){ //string의 내용을 a의 내용과 비교하여 반환
return strcmp(str, a.contents());
}
int Str::compare(char *a){ //a내용을 비교하여 반환
return strcmp(str, a);
}
void Str::operator=(char *a){
delete[] str;
len = strlen(a);
str=new char[len];
strcpy(str, a);
}
void Str:: operator=(class Str &a){//Str의 내용을 대입한다. 
delete[] str;
len = a.length();
str = new char[len];
strcpy(str,a.contents());

}
