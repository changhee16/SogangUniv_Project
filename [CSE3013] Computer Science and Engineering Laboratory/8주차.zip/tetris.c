﻿#include "tetris.h"

static struct sigaction act, oact;
int recommendFlag;
int main(){
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);	

	srand((unsigned int)time(NULL));
	createRankList();
	while(!exit){
		clear();
		switch(menu()){
		case MENU_PLAY: play(); break;
		case MENU_RANK: rank(); break; //rank누르는 경우도 추가.
		case MENU_EXIT: exit=1; break;
		default: break;
		}
	}
       writeRankFile();
	endwin();
	system("clear");
	return 0;
}

void InitTetris(){
	int i,j,k;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	for(k=0;k<BLOCK_NUM;k++)
	    nextBlock[i]=rand()%7;
	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;
	
	
/*	recRoot=(RecNode*)malloc(sizeof(RecNode));
		for(j=0;j<HEIGHT;j++)
			for(i=0;i<WIDTH;i++){
				recRoot->f[j][i]=0;
			}
		recRoot->lv=0;
		recRoot->score=0;
		for(i=0;i<CHILDREN_MAX;i++)
			recRoot->c[i]=NULL;
		recommend(recRoot);*/
	DrawOutline();
	DrawField();
	//DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline(){	
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);
	
	//2번재 next block을 보여주는 공간의 테두리를 그린다.
        move(7,WIDTH+10);
	DrawBox(8,WIDTH+10,2,8);
	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(9,WIDTH+10);
	printw("SCORE");
	DrawBox(10,WIDTH+10,1,8);
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	if(command !=QUIT && recommendFlag==1){
		return KEY_DOWN;
}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


void PrintScore(int score){
	move(11,WIDTH+11);
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock){
	int i, j, k;
       for(k=1;k<3;k++){
	for( i = 0; i < 4; i++ ){
		move(4+i+(k-1)*6,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[k]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}
}
void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			free(recRoot);
			recRoot=NULL;
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();
			if(recommendFlag==0){
			newRank(score); //Quit할 때도 newRand불러옴.
		}
			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	if(recommendFlag==0){
	newRank(score);
}}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

/////////////////////////첫주차 실습에서 구현해야 할 함수/////////////////////////

int CheckToMove(char f[HEIGHT][WIDTH], int currentBlock, int blockRotate, int blockY, int blockX){
	// user code
int i,j;
for(i=0;i<4;i++)
{
  for(j=0;j<4;j++){
  if( block[currentBlock][blockRotate][i][j]==1){
    int rx = blockX+j;
    int ry = blockY+i;
   if(f[ry][rx] == 1) {
     return 0;}
    else if((ry>=HEIGHT)|(rx<0)|(rx>=WIDTH)){
     return 0;}
}
}
}
	return 1;
 }
void DrawChange(char f[HEIGHT][WIDTH], int command, int currentBlock, int blockRotate, int blockY, int blockX){
	// user code

	//1. 이전 블록 정보를 찾는다. ProcessCommand의 switch문을 참조할 것
	//2. 이전 블록 정보를 지운다. DrawBlock함수 참조할 것.
	//3. 새로운 블록 정보를 그린다. 
int i,j;
char title='.';
switch(command){
	case KEY_UP:
	// blockRotate=(blockRotate+3)%4;
  	  for(i=0;i<4;i++){
	   for(j=0;j<4;j++){
		if(block[currentBlock][(blockRotate+3)%4][i][j]==1 && i+blockY>=0){
			move(i+blockY+1,j+blockX+1);
			printw("%c",title);
			}
		}}
	   break;
	case KEY_DOWN:
	 //blockY--;
   	  for(i=0;i<4;i++){
	   for(j=0;j<4;j++){
		if(block[currentBlock][blockRotate][i][j]==1 && i+blockY+1>=0){
			move(i+blockY,j+blockX+1);
			printw("%c",title);
			}
		}}
  	   break;
	case KEY_LEFT:
	// blockX++;
   	  for(i=0;i<4;i++){
	   for(j=0;j<4;j++){
		if(block[currentBlock][blockRotate][i][j]==1 && i+blockY>=0){
			move(i+blockY+1,j+blockX+1+1);
			printw("%c",title);
			}
		}}
  	   break;
	case KEY_RIGHT:
	// blockX--;
   	  for(i=0;i<4;i++){
	   for(j=0;j<4;j++){
		if(block[currentBlock][blockRotate][i][j]==1 && i+blockY>=0){
			move(i+blockY+1,j+blockX);
			printw("%c",title);
			}
		}}
  	   break;}
  DrawBlockWithFeatures(blockY,blockX,currentBlock,blockRotate);
//move(HEIGHT,WIDTH+10);


}

int AddBlockToField (char f[HEIGHT][WIDTH], int currentBlock, int blockRotate, int blockY, int blockX ){
	// user code

	//Block이 추가된 영역의 필드값을 바꾼다.
int i,j;
int count=0;
for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	if (block[currentBlock][blockRotate][i][j]==1){
	 if(0<=blockY+1 && blockY+i <HEIGHT && 0 <= blockX+j && blockX+j < WIDTH) {
                f[blockY+i][blockX+j] = 1;
		if(blockY+i == HEIGHT-1)
		 count++;}

}}
}
return count*10;
}
int DeleteLine(char field[HEIGHT][WIDTH]){
int flag;	
int line =0;
int i,j,k;
for(i=0;i<HEIGHT;i++){
	flag =1;
 	for(j=0;j<WIDTH;j++){
	 if (field[i][j]==0){
		flag=0;
		break;
	}
			}
	 if (flag==1){
	  line++;
	 for(k=i-1;k>=0;k--){
	   for(j=WIDTH;j>0;j--){
		field[k+1][j]=field[k][j];
	   }
        } 
	}
}
return (line*line*100);

}
void BlockDown(int sig){
	// user code

	if(recommendFlag == 1) {
		blockY = recommendY;
		blockX = recommendX;
		blockRotate = recommendR;
	}
	//강의자료 p26-27의 플로우차트를 참고한다.
if(CheckToMove(field, nextBlock[0],blockRotate,blockY+1,blockX)){ 
 blockY++;
 DrawChange(field,KEY_DOWN,nextBlock[0],blockRotate,blockY,blockX);}
 else{
    if (blockY==-1){ 
    gameOver = 1;
    return;
}
   score+= AddBlockToField(field,nextBlock[0],blockRotate,blockY,blockX);
   score+=DeleteLine(field);
    for(int i = 0; i < BLOCK_NUM-1; i++) {
	nextBlock[i] = nextBlock[i+1];
			}
  // nextBlock[0]=nextBlock[1];
  // nextBlock[1]=nextBlock[2];
   nextBlock[BLOCK_NUM-1]=rand()%7;
   blockRotate=0;
   blockY=-1;
   blockX=WIDTH/2-2;
   DrawNextBlock(nextBlock);
   PrintScore(score);
   DrawField();
}
   timed_out=0;
}

///////////////////////////////////////////////////////////////////////////

void DrawShadow(int y, int x, int blockID,int blockRotate){
 char title ='/';	// user code
 int dropY=y;
 while(CheckToMove(field, nextBlock[0], blockRotate, dropY+1, x))
		dropY++;
 //가장 바닥에 있을 때 위치
 DrawBlock(dropY,x,blockID,blockRotate,'/');
}


/*void DrawBlockWithFeatures(int y, int x, int blockID,int blockRotate) {//두가지 함수 호출
	DrawRecommend(recommendY, recommendX, blockID, recommendR);
	if (recommendFlag==0){
	DrawShadow(y, x, blockID, blockRotate);
	}DrawBlock(y, x, blockID, blockRotate, ' ');
}
*/
typedef struct _Node{ //연결리스트를 구현할 구조체
 
   char Name[NAMELEN];
   int Score;
   struct _Node* next; //link역할을 하는 노드 정의
}Node;
Node* head=NULL; //첫 번째 노드


void createRankList(){

int number;
FILE *fp;
int i;
 
fp=fopen("rank.txt","r");

fscanf(fp, "%d",&number);//현재 랭킹 정보의 개수 입력받기

for(i=0;i<number;i++){ //제공된 것은 if문이었는데 for문 형태로 바꿈
  Node *newNode=(Node*)malloc(sizeof(Node));
  newNode->next=NULL;
 fscanf(fp,"%s %d\n",newNode->Name, &newNode->Score);
  if(head ==NULL){
   head = newNode;
 }
 else{
   Node *temp=head;
   while(temp->next!=NULL){
        temp=temp->next;
      }
       temp->next=newNode;
}


}
fclose(fp);
}

void rank(){ //인자를 가져오도록 수정

//목적: rank 메뉴를 출력하고 점수 순으로 X부터~Y까지 출력함
//1. 문자열 초기화

 clear();
//2. printw()로 3개의 메뉴출력
 printw("1. list ranks from X to Y\n");
 printw("2. list ranks by a specific name\n");
 printw("3. delete a sepcific rank\n");

//3. wgetch()를 사용하여 변수 ch에 입력받은 메뉴번호 저장

// ch=wgetch(stdscr);
 int score_number;
 FILE* fp=fopen("rank.txt","r");
 fscanf(fp, "%d",&score_number);
 int X=1;
 int Y=score_number;
 int  ch, i, j;
 int count;
 ch=wgetch(stdscr); 
//4. 각 메뉴에 따라 입력받을 값을 변수에 저장
//4-1. 메뉴1: X, Y를 입력받고 적절한 input인지 확인 후(X<=Y), X와 Y사이의 rank 출력
 if (ch == '1') {
	printw("X: ");
        echo();
	scanw("%d", &X);
	printw("Y: ");
        echo();
	scanw("%d", &Y);
	noecho();
	printw("       name         |       scre     \n");
        printw("--------------------------------------\n");
        if(X>Y || score_number == 0|| X>score_number){
          mvprintw(8,0,"search failure: no rank in the list\n");}
        else{
         Node* currNode=head;
	 /* currNode->Name;
	currNode->Score;*/
	count =0;
        while(1){
	count++;
	 if((count>=X)&&(count<=Y))
	  {printw(" %-20s| %-20d\n", currNode->Name, currNode->Score);
	   currNode=currNode->next;
	}
         else if (count>Y||currNode->next==NULL) break;
         else
           currNode=currNode->next;}
          
}
}
	//4-2. 메뉴2: 문자열을 받아 저장된 이름과 비교하고 이름에 해당하는 리스트를 출력
	else if ( ch == '2') {
		Node* temp= head;
		char str[NAMELEN+1];
		int check = 0;
		printw("Name: ");
		echo();	
         	scanw("&s",str);
		noecho();
	 	printw("       name         |       scre     \n");
       		printw("--------------------------------------\n");
 		for(int i=0;temp!=NULL;i++){
		 if(strcmp(temp->Name,str)==0){
                      printw(" %-20s| %-20d\n", temp->Name, temp->Score);
		      check=1;
}
                 else{
	             temp=temp->next;
}
}	
     	if(check!=1) printw("search failure: no name in the list\n");
	}

	//4-3. 메뉴3: rank번호를 입력받아 리스트에서 삭제
	else if ( ch == '3') {
		int num;
		Node* temp;
		Node* prev;
		temp=head;
		prev=head;
		printw("rank number: ");
		echo();
		scanw("%d",&num);
		noecho();
		if(num<=score_number){
	        	for(int i=0;i<num;i++){
		        temp=temp->next;
		         prev->next=temp;
}
		prev->next=temp->next;
		printw("result: the rank deleted");
		free(temp);
}
		 else printw("search failure: the rank not in the list");
	}
	getch();
}
void writeRankFile(){
	
 // 목적: 추가된 랭킹 정보가 있으면 새로운 정보를 "rank.txt"에 쓰고 없으면 종료
 int i, sn;
 int score_number=0;
 Node* addNode=head;
 Node* check=head;
//1. "rank.txt" 연다
 FILE *fp = fopen("rank.txt", "rw");
  //2. 랭킹 정보들의 수를 "rank.txt"에 기록
  fscanf(fp,"%d\n",&sn);
  while(check!=NULL){
  check=check->next;
  score_number++;
}
  if(sn!=score_number){
  fprintf(fp,"%d\n",score_number);//수 갱신
   for(i=0;i<score_number;i++){
   fprintf(fp, "%s %d\n",addNode->Name, addNode->Score);
    //3. 탐색할 노드가 더 있는지 체크하고 있으면 다음 노드로 이동, 없으면 종료
   addNode=addNode->next;
  }
 }
  // fprintf(fp, "%s %d\n",head->Name, head->Score);
   free(head);
 //3. 탐색할 노드가 더 있는지 체크하고 있으면 다음 노드로 이동, 없으면 종료
/* if ( sn == score_number) return;
 else {
  fprintf(fp,"%d\n",sn);
  for(i=0;i<sn;i++){
   fprintf(fp,"%s  %d\n",addNode->Name, addNode->Score);
   addNode=addNode->next;
}
 }*/
/* for ( i= 1; i < score_number+1 ; i++) {
	free(Node->Name);
 }
 free(Node->Name);
 free(Node->Score);*/
}

void newRank(int score){
 char str[NAMELEN+1];
 int i=0,j=0;//prevnode를 찾아내기 위한 count변수
 int rank;
 Node* p=head; //등수 갱신을 위한 노드 정의
 clear();
 echo();
 printw("your name: ");
 Node* newNode=(Node*)malloc(sizeof(Node));
 scanw("%s\n",newNode->Name);
 newNode->Score=score;
 noecho();
// Node* newNode; //str을 담을 새로운 노드 정의
// strcpy(newNode->Name,str);
// newNode->Score=score;
 Node* prevNode=head; //Node의 중간삽입이 이루어지려면 이전 노드를 알아야한다. 이전 노드 정의
 
 while(1){
  if((p->Score)>(newNode->Score)){
        p=p->next;
        i++;} //만약 기존 점수가 p보다 크면 다음 사용자의 점수로 이동,
   else 
     break;}

 for(j=0;j<i;j++){ 
 prevNode=prevNode->next;
}
 newNode->next=prevNode->next;//새로운 노드 삽입
 prevNode->next=newNode;
 
writeRankFile();
}



void DrawRecommend(int y, int x, int blockID,int blockRotate){
	// user code
	DrawBlock(y,x,blockID,blockRotate,'R');

}
int recommend(RecNode *root){
/*	RecNode node;
	RecNode* childNode=&node;
        int x,y,rotate;
	int cScore;
	int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수
	for(rotate=0;rotate<4;rotate++){
	  for(x=-2;x<WIDTH+3;x++){
	   if(CheckToMove(root->f,nextBlock[root->lv],rotate,0,x)==0){
	    continue;}

	memcpy(childNode->*f,root->*f,sizeof(*f));
	childNode->lv=root->lv+1;

	y=DropPosition(childNode->*f,y,x,nextBlock[root->lv],rotate);
	cScore=AddBlockToField(childNode->*f,nextBlock[root->lv],rotate,x,y);	
        int FullLine=DeleteLine(childNode->f);
	cScore+=(FullLine*FullLine)*100;

	if((childNode->lv) <(VISIBLE_BLOCKS))
	 cScore+=recommend(childNode);
	
	if(max<=cScore){
	 if((root->lv==0)&&(max<cScore ||y>recommendY)){

	 recommendY=y;
	 recommendX=x;
	 recommendR=rotate;
}
	max=cScore;
}
	// user code
}
}
	return max;*/
int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수
	int block_r,block_y,block_x,temp_score,idx=0;
	int i,j,r,x,y,lv,tmp;


	RecNode *new_node;
	lv=root->lv+1;
	for(r=0;r<4;r++){
		if(r == 1 && nextBlock[lv-1] == 4)
			break;
		else if(r == 2){
			tmp=nextBlock[lv-1];
			if(tmp == 0 || tmp == 5 || tmp == 6)
				break;
		}
		for(x=-2;x<WIDTH;x++){
			y=-1;
			while(CheckToMove(root->f,nextBlock[lv-1],r,y,x))
				y++;
			if(y == -1)
				continue;
				y--;
			new_node=(RecNode*)malloc(sizeof(RecNode));
			new_node->lv=lv;
			new_node->score=root->score;
			for(i=0;i<HEIGHT;i++)
				for(j=0;j<WIDTH;j++)
					new_node->f[i][j]=root->f[i][j];
			for(i=0;i<CHILDREN_MAX;i++)
				new_node->c[i]=NULL;
			new_node->score+=AddBlockToField(new_node->f,nextBlock[lv-1],r,y,x);
			new_node->score+=DeleteLine(new_node->f);
			root->c[idx++]=new_node;
			if(new_node->lv < BLOCK_NUM){
				temp_score=recommend(new_node);
			}
			else
				temp_score=new_node->score;
			if(max<temp_score){
				max=temp_score;
				block_r=r;
				block_x=x;
				block_y=y;
			}
		}
	}
	if(root->lv == 0){
		recommendR=block_r;
		recommendY=block_y;
		recommendX=block_x;
	}
	return max;
}
void recommendedPlay(){
	// user codeㅑ
	recommendFlag=1;
	play();
	recommendFlag=0;
}
void DrawBlockWithFeatures(int y, int x, int blockID,int blockRotate) {//두가지 함수 호출
	DrawRecommend(recommendY, recommendX, blockID, recommendR);
	if (recommendFlag==0){
	DrawShadow(y, x, blockID, blockRotate);
	}DrawBlock(y, x, blockID, blockRotate, ' ');
}
