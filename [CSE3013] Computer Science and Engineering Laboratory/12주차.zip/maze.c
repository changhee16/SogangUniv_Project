#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NONE 0 

//비트연산을 이용하여 위, 아래, 왼, 오를 구분한다. 
#define LEFT 8 //1000
#define RIGHT 4 //0100
#define TOP 2//0010
#define BOTTOM 1//0001
#define BLOCK 16 //1111


int getRandDirection() {
    int d = rand() % 4;
    switch(d){
        case 0:
            return LEFT; 
        case 1:
            return RIGHT;
        case 2:
            return BOTTOM;
        case 3:
            return TOP;
    }
}

void getDirectionChar(int left, int me, int top, int row, char* c) {
    if(row == 0){
        c[0] = '+'; 
        if((me >> 1) & 1 || top & 1){
            c[1] = ' ';  
        }
        else{
            c[1] = '-';  
        }
    }
    if(row == 1){
        if((me >> 3) & 1 || (left >> 2) & 1) {
            c[0] = ' ';
        }else{
            c[0] = '|';
        }       
    }
}

void printMaze(int** a, int xsize, int ysize) {

   FILE* fp;
   fp=fopen("maze.maz","w");
    for(int j = 0; j < ysize; j++) {
       for(int k = 0; k < 2; k++) {
            for(int i = 0; i < xsize; i++) {                
                int left, me, top;      

                left = i > 0 ? a[i - 1][j] : BLOCK;                
                top = j > 0 ? a[i][j - 1] : BLOCK;              

                char c[2] = { ' ', ' '};
                getDirectionChar(left, me, top, k , c);
                fputc(c[0],fp);
                fputc(c[1],fp);
            }

            if(k==0) fputs("+\n",fp);
            else fputs("|\n",fp);
        };
    }
    for(int i = 0; i < xsize; i++) {
        fputs("+-",fp);
    }
    fputs("+\n",fp);
    fclose(fp);
}

int goForward(int** a, int x, int y,int xsize, int ysize){
       while(1) {
        if((x==0||( a[x - 1][y] != 0)) && //LEFT is disable
            (x == xsize - 1 || a[x + 1][y] != 0) && //RIGHT is disable
            ( y==0||a[x][y - 1] != NONE) && //TOP is diable
            (y == ysize - 1 || a[x][y + 1] != 0)) { //BOTTOM is diable
                return 0;
        }
  int d = getRandDirection();

        switch(d){
            case LEFT:
                if(x > 0 && a[x - 1][y] == 0) { 
                    a[x][y] += LEFT;
                    x--;
                    goForward(a, x, y,xsize, ysize);
                    a[x][y] += RIGHT;
                }
                break;
            case RIGHT:
                if(x < xsize - 1 && a[x + 1][y] == NONE) {
                    a[x][y] += RIGHT;
                    x++;
                    goForward(a, x, y,xsize, ysize);
                    a[x][y] += LEFT;
                }
                break;
            case TOP:
                if(y > 0 && a[x][y - 1] == NONE) {
                    a[x][y] += TOP;
                    y--;
                    goForward(a, x, y,xsize, ysize);
                    a[x][y] += BOTTOM;
                }
                break;
            case BOTTOM:
                if(y < ysize - 1 && a[x][y + 1] == NONE) {
                    a[x][y] += BOTTOM;
                    y++;
                    goForward(a, x, y,xsize, ysize);
                    a[x][y] += TOP;
                }
                break;
        }
    }
}

int main(){
  int xsize;
  int ysize;
  
  scanf("%d\n",&xsize);
  scanf("%d", &ysize);
    
    srand(time(NULL));
 int** a=malloc(sizeof(int*)*xsize);

 for(int i=0;i<xsize;i++){
  a[i]=malloc(sizeof(int)*ysize);//2차원 배열 a 생성
}

    for(int i = 0; i < xsize; i++) {
        for(int j = 0; j < ysize; j++) {
            a[i][j] = 0;
        }
    }
    a[0][0] = LEFT;
    goForward(a, 0, 0,xsize, ysize);
    printMaze(a, xsize, ysize );
    for(int i=0;i<xsize;i++) free(a[i]);
    free(a);

}
