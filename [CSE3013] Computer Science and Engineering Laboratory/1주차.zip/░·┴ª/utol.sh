echo "working directory:"
read directory					

if [ $directory ]		
then
	cd $directory					
	if [ $? -ne 0 ]			
	then					
		echo "Error!"
		exit 0
	fi
fi

for i in *				
do
	if [ -f "$i" ]			
	then					
		mv $i `echo $i | tr '[:upper:][:lower:]' '[:lower:][:upper:]'`	
	fi
done

