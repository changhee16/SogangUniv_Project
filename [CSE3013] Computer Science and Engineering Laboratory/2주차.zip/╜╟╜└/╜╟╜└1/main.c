#include <stdio.h>

int main(void)
{
	dog();
	blackcow();
	turtle();
	return 0;
}
