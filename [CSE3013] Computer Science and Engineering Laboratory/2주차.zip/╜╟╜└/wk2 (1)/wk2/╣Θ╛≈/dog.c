#include "animal.h"
void dog()
{
 printf("Bark\n");
}
