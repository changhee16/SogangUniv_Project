#include "stdio.h"
void turtle()
{
printf("Turtle\n");
}
