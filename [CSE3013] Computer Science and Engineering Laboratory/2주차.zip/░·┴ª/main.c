#include "starwars.h"
int main(){
int test;
scanf("%d", &test);//테스트의 개수 입력받기
int *input=NULL; //테스트 페이지 입력 받을 배열 정의
input=(int*)malloc(sizeof(int)*test);
for(int i=0;i<test;i++) 
{
scanf("%d", &input[i]); //페이지 입력 받고 input에 각각  할당
}
for(int i=0;i<test;i++)
{
int *numArr= NULL;
numArr=(int*)malloc(sizeof(int)*input[i]);
int countArr[10]={0, }; //페이지를 구성하는 숫자 개수를 담을 배열 정의(0~9)
for(int j=0;j<input[i];j++)
{	
	numArr[j]=j+1;
}
int num=input[i];
count(countArr,num);
print(countArr);
free(numArr);
}
free(input);
return 0;
}

