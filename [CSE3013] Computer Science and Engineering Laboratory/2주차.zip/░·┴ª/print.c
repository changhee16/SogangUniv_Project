#include"starwars.h"

int print(int countArr[])
{

for( int i=0; i<=9; i++) //배열의 요소 개수만큼 반복
{
printf("%d ", countArr[i]);
}
printf("\n");
return 0;
}
