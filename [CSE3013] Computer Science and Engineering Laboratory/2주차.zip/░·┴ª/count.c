//count,c
#include "starwars.h"
void count(int countArr[], int num)
{
for(int i=0; i<=num;i++) //배열의 요소 개수만큼 반복
{
int t=i;
while(t){
countArr[t%10]++;
t/=10;
}
}
}
