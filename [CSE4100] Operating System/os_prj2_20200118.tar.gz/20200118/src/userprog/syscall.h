#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "devices/shutdown.h"
typedef int pid_t;

static void syscall_handler (struct intr_frame *);
void syscall_init (void);
void check_user_vaddr(const void *vaddr);
void  sys_halt(void);
void  sys_exit(int status);
int max_of_four_int (int a, int b, int c, int d);
int fibonacci (int n);
pid_t sys_exec (const char *cmd_line);
int sys_wait (pid_t pid);
int sys_read (int fd , void * buffer , unsigned size);
int sys_write (int fd , void * buffer , unsigned size);
bool sys_create (const char *file, unsigned initial_size);
bool sys_remove (const char *file);
int sys_open (const char *file);
int sys_filesize (int fd);
void sys_seek (int fd, unsigned position);
unsigned sys_tell (int fd);
void sys_close (int fd);

#endif /* userprog/syscall.h */
