#include "process.h"
#include <string.h>

char	**ft_addr_input(char    **argv)
{
	char	**addr;
	int		argc;
	int		i;

	i = -1;
	while (argv[++i])
		argc++;
	addr = (char	**)malloc(sizeof(char	*) * argc);

	for (i = 0; i < argc; i++)
	{
		addr[i] = strdup(&(argv[i]));
	}
}