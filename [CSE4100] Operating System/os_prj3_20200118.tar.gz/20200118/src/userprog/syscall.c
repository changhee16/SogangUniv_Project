#include "syscall.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include <string.h>

/* 1106 add */
struct lock file_lock; 

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  int a, b, c, d; //to implement max
  switch(*(uint32_t *)(f->esp))
  {
    case SYS_HALT:
      sys_halt();
      break;
    case SYS_EXIT:
      check_user_vaddr(f->esp + 4);
      sys_exit(*(uint32_t *)(f->esp + 4));
      break;
     case SYS_EXEC:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_exec((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_wait(*(pid_t *)(f->esp + 4));     
      break;
    case SYS_CREATE:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      f->eax = sys_create((const char *)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_REMOVE:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_remove((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_OPEN:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_open((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_filesize((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_READ:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = sys_read((int)*(uint32_t *)(f->esp+4), (void*)*(uint32_t *)(f->esp+8),(unsigned)*(uint32_t *)(f->esp+12));
      break;
    case SYS_WRITE:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = sys_write((int)*(uint32_t*)(f->esp+4), (void*)*(uint32_t *)(f->esp+8),(unsigned)*(uint32_t *)(f->esp+12));
      break;
    case SYS_SEEK:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      sys_seek((int)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_TELL:
      check_user_vaddr(f->esp + 4);
      f->eax = sys_tell((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_CLOSE:
      check_user_vaddr(f->esp + 4);
      sys_close((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_MAX:
      check_user_vaddr(f->esp + 4);
      a = (int)*(uint32_t *)(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      b = (int)*(uint32_t *)(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      c = (int)*(uint32_t *)(f->esp + 12);
      check_user_vaddr(f->esp + 16);
      d = (int)*(uint32_t *)(f->esp + 16);
      f->eax = max_of_four_int(a, b, c, d);
      break;
    case SYS_FIB:
     check_user_vaddr(f->esp + 4);
     f->eax = fibonacci((int)*(uint32_t *)(f->esp + 4));
      break;
  }
}

void check_user_vaddr(const void *vaddr){
	if(!is_user_vaddr(vaddr))
		sys_exit(-1);
}

void
syscall_init (void) 
{
  lock_init(&file_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void  sys_halt(void)
{
  shutdown_power_off();
}

void   sys_exit(int status)
{
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status; 
	for(int i = 3; i < 128; i++)
  {
		if(thread_current()->fd[i] != NULL)
			sys_close(i);
	}
  thread_exit();
}

int max_of_four_int (int a, int b, int c, int d)
{  
  int max;

  if ((a >= b) && (a >= c) && (a >= d))
    max = a;
  else if ((b >= a) && (b >= c) && (b >= d))
    max = b;
  else if ((c >= a) && (c >= b) && (c >= d))
    max = c;
  else
    max = d;
  return max;
}

//recursive

int fibonacci (int n)
{
	if (n < 2)
    return n;

	return (fibonacci(n - 1) + fibonacci (n - 2));
}

pid_t sys_exec (const char *cmd_line)
{
  return process_execute(cmd_line);
}

int sys_wait (pid_t pid)
{
  return process_wait(pid);
}

int sys_read (int fd , void * buffer , unsigned size)
{
  int i, res;
  check_user_vaddr(buffer);
  lock_acquire(&file_lock);
  if (fd == 0)
  {
    for(i = 0; i < (int)size; i++)
    {
      uint8_t c = input_getc();
      if (c == '\0')
        break;
    }
    lock_release(&file_lock);
    return i;
  }
  else if (fd > 2)
  {
    if (thread_current()->fd[fd] == NULL)
    {
      lock_release(&file_lock);
      sys_exit(-1);
    }
    else
    {
      res = file_read(thread_current()->fd[fd], buffer, size);
      lock_release(&file_lock);
      return res;
    }
  }
  lock_release(&file_lock);
  return -1;
}

int sys_write (int fd , void * buffer , unsigned size)
{
  check_user_vaddr(buffer);
  lock_acquire(&file_lock);
  if (fd == 1)
  {
    putbuf(buffer, size);
    lock_release(&file_lock);
    return size;
  }
  else if (fd > 2)
  {
    if (thread_current()->fd[fd] == NULL)
    {
      lock_release(&file_lock);
      sys_exit(-1);
    }
    else
    {
      lock_release(&file_lock);
      return file_write(thread_current()->fd[fd], buffer, size);
    }
  }
    lock_release(&file_lock);
    return -1;
}

bool sys_create (const char *file, unsigned initial_size)
{
 if (file == NULL)
  sys_exit(-1);
return filesys_create(file, initial_size);
}

bool sys_remove (const char *file)
{
  if (file == NULL)
    sys_exit(-1);
  return filesys_remove(file);
}

int sys_open (const char *file)
{
  struct file *ret_file;

  lock_acquire(&file_lock);
  if (file == NULL)
  {
    lock_release(&file_lock);
    sys_exit(-1);
  }
  ret_file = filesys_open(file);
  if (ret_file == NULL)
  {
    lock_release(&file_lock);
    return -1;
  }
  else
  {
    for (int i = 3; i < 128; i++) //fd = 0, 1, 2 except
    {
      if (thread_current()->fd[i] == NULL)
      {
        if (!strcmp(thread_current()->name, file))
          file_deny_write(ret_file);
        thread_current()->fd[i] = ret_file;
        lock_release(&file_lock);
        return i;
      }
    }
  }
  lock_release(&file_lock);
  return -1;
}

int sys_filesize (int fd)
{
  if (thread_current()->fd[fd] == NULL)
    sys_exit(-1);
  return file_length(thread_current()->fd[fd]);
}

void sys_seek (int fd, unsigned position)
{
  if (thread_current()->fd[fd] == NULL)
    sys_exit(-1);
  file_seek(thread_current()->fd[fd], position);
}

unsigned sys_tell (int fd)
{
  if (thread_current()->fd[fd] == NULL)
    sys_exit(-1);
  return file_tell(thread_current()->fd[fd]);
}

void sys_close (int fd)
{
  if (thread_current()->fd[fd] == NULL)
    sys_exit(-1);
  file_close(thread_current()->fd[fd]);
  thread_current()->fd[fd] = NULL;
}
