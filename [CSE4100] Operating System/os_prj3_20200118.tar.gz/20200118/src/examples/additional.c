#include <stdio.h>
#include <syscall.h>
#include <stdlib.h>

int main (int argc, char**argv)
{	
    int num_1, num_2, num_3, num_4;
    if (argc == 5)
    {
        num_1 = atoi(argv[1]);
        num_2 = atoi(argv[2]);
        num_3 = atoi(argv[3]);
        num_4 = atoi(argv[4]);
        printf("%d %d\n", fibonacci(num_1), max_of_four_int(num_1, num_2, num_3, num_4));
        return 0;
    }
    else
    {
        printf("invalid argument number\n");
        return -1;
    }
}