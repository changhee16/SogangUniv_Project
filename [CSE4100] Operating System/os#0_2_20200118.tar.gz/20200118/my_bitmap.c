#include "my_bitmap.h"


int	match_bitmap_index(char	*name)
{
	int bitmap_index;

	bitmap_index = -1;

	while (++bitmap_index < 10)
	{
		if (!strcmp(g_bitmap_data[bitmap_index].name, name))
		{
			return (bitmap_index);
		}
	}
	return (-1);
}

int check_null_bitmap()
{
	int i;

	i = -1;
	while (++i < 10)
	{
		if (!g_bitmap_data[i].link)//strcmp(g_list_data[i].name, "\0"))
			break;
	}
	return (i);
}

void	create_bitmap(char	*name, int cnt)
{
	int bitmap_index;

	if ((bitmap_index = check_null_bitmap()) < 0)
		return ;
	strcpy(g_bitmap_data[bitmap_index].name, name);
	g_bitmap_data[bitmap_index].link = bitmap_create(cnt);
}

void	dump_bitmap(char	*name)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	for (int i = 0; i < bitmap_size(b); i++)
	{
		printf("%d", bitmap_test(b, i));
	}

	printf("\n");
}

void	func_delete_bitmap(char	*name)
{
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	bitmap_destroy(g_bitmap_data[bitmap_index].link);
	g_bitmap_data[bitmap_index].link = NULL;
	g_bitmap_data[bitmap_index].name[0] = '\0';
}
void	func_bitmap_all(char	*name, int start, int cnt)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (bitmap_all(b, start, cnt))
		printf("true\n");
	else
		printf("false\n");
}

void	func_bitmap_any(char	*name, int start, int cnt)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (bitmap_any(b, start, cnt))
		printf("true\n");
	else
		printf("false\n");
}

void	func_bitmap_none(char	*name, int start, int cnt)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (bitmap_none(b, start, cnt))
		printf("true\n");
	else
		printf("false\n");
}
void	func_bitmap_mark(char	*name, int index)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	bitmap_mark(b, index);
}

void	func_bitmap_size(char	*name)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	printf("%zu\n", bitmap_size(b));
}

void	func_bitmap_flip(char	*name, int index)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	bitmap_flip(b, index);
}

void	func_bitmap_reset(char	*name, int index)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	bitmap_reset(b, index);
}

void	func_bitmap_test(char	*name, int index)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if(bitmap_test(b, index))
		printf("true\n");
	else
		printf("false\n");
}
void	func_bitmap_contains(char	*name, int start, int cnt, char *type)
{
	struct bitmap	*b;
	int bitmap_index;
	int	result;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		result = bitmap_contains(b, start, cnt, true);
	else if (!strcmp(type, "false"))
		result = bitmap_contains(b, start, cnt, false);
	if (result)
		printf("true\n");
	else
		printf("false\n");
}

void	func_bitmap_count(char	*name, int start, int cnt, char *type)
{
	struct bitmap	*b;
	int bitmap_index;
	size_t	result;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		result = bitmap_count(b, start, cnt, true);
	else if (!strcmp(type, "false"))
		result = bitmap_count(b, start, cnt, false);
	printf("%zu\n", result);
}

void	func_bitmap_set(char	*name, int index, char *type)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		bitmap_set(b, index, true);
	else if (!strcmp(type, "false"))
		bitmap_set(b, index, false);
}

void	func_bitmap_set_multiple(char	*name, int start, int cnt, char *type)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		bitmap_set_multiple(b, start, cnt, true);
	else if (!strcmp(type, "false"))
		bitmap_set_multiple(b, start, cnt, false);
}

void	func_bitmap_set_all(char	*name, char *type)
{
	struct bitmap	*b;
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		bitmap_set_all(b, true);
	else if (!strcmp(type, "false"))
		bitmap_set_all(b, false);
}

void	func_bitmap_scan(char	*name, int start, int cnt, char *type)
{
	struct bitmap	*b;
	int bitmap_index;
	size_t result;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		result = bitmap_scan(b, start, cnt, true);
	else if (!strcmp(type, "false"))
		result = bitmap_scan(b, start, cnt, false);
	printf("%zu\n", result);
}

void	func_bitmap_scan_and_flip(char	*name, int start, int cnt, char *type)
{
	struct bitmap	*b;
	int bitmap_index;
	size_t result;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	b = g_bitmap_data[bitmap_index].link;
	if (!strcmp(type, "true"))
		result = bitmap_scan_and_flip(b, start, cnt, true);
	else if (!strcmp(type, "false"))
		result = bitmap_scan_and_flip(b, start, cnt, false);
	printf("%zu\n", result);
}

void	func_bitmap_dump(char	*name)
{
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	bitmap_dump(g_bitmap_data[bitmap_index].link);
}

void	func_bitmap_expand(char	*name, int size)
{
	int bitmap_index;

	if ((bitmap_index = match_bitmap_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	g_bitmap_data[bitmap_index].link = bitmap_expand(g_bitmap_data[bitmap_index].link, size);
}