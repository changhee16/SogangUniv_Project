#include <stdio.h>
#include <string.h>
#include "list.h"

#define BACK 0
#define FRONT 1
#define MIN 0
#define MAX 1

int	match_list_index(char	*name);
int check_null_list();
void	create_list(char	*name);
void	dump_list(char	*name);
void	func_list_front_back(char *name, int flag);
void	func_list_pop_front_back(char	*name, int flag);
void	func_list_remove(char	*name, int	index);
void	func_list_push_front_back(char	*name, int num, int flag);
void	func_list_empty(char	*name);
void	func_list_size(char		*name);
void	func_list_max_min(char		*name, int flag);
void	func_delete_list(char	*name);
void	func_list_reverse(char *name);
void	func_list_inserted_ordered(char	*name, int data);
void	func_list_sort(char	*name);
void	func_list_swap(char	*name, int a, int b);
void	func_list_shuffle(char	*name);
void	func_list_unique_1(char	*name);
void	func_list_unique_2(char	*name_1, char	*name_2);
void	func_list_insert(char	*name, int index, int data);
void    func_list_splice(char   *name_1, int index_1, char	*name_2, int start, int end);
