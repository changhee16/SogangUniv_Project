#include <stdio.h>
#include <string.h>
#include "bitmap.h"

int	match_bitmap_index(char	*name);
int check_null_bitmap();
void	create_bitmap(char	*name, int cnt);
void	dump_bitmap(char	*name);
void	func_delete_bitmap(char	*name);
void	func_bitmap_all(char	*name, int start, int cnt);
void	func_bitmap_any(char	*name, int start, int cnt);
void	func_bitmap_mark(char	*name, int index);
void	func_bitmap_contains(char	*name, int start, int cnt, char *type);
void	func_bitmap_count(char	*name, int start, int cnt, char *type);
void	func_bitmap_flip(char	*name, int index);
void	func_bitmap_none(char	*name, int start, int cnt);
void	func_bitmap_reset(char	*name, int index);
void	func_bitmap_test(char	*name, int index);
void	func_bitmap_size(char	*name);
void	func_bitmap_set(char	*name, int index, char *type);
void	func_bitmap_set_multiple(char	*name, int start, int cnt, char *type);
void	func_bitmap_set_all(char	*name, char *type);
void	func_bitmap_scan(char	*name, int start, int cnt, char *type);
void	func_bitmap_scan_and_flip(char	*name, int start, int cnt, char *type);
void	func_bitmap_dump(char	*name);
void	func_bitmap_expand(char	*name, int size);