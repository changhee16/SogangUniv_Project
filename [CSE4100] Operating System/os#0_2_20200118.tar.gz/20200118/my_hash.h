#include <stdio.h>
#include <string.h>
#include "hash.h"

int check_null_hash();
int	match_hash_index(char	*name);
void	dump_hash(char	*name);
void	create_hash(char	*name);
void	func_hash_insert(char	*name, int data);
void	func_hash_size(char	*name);
void	func_hash_empty(char	*name);
void	func_delete_hash(char	*name);
void	func_one_delete_hash(char	*name, int data);
void	func_hash_clear(char	*name);
void	func_hash_find(char	*name, int data);
void	func_hash_apply(char	*name, char	*func);
void	func_hash_replace(char	*name, int data);