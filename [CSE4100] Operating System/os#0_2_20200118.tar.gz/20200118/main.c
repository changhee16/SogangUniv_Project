#include "list.h"
#include "hash.h"
#include "bitmap.h"
#include "ft_split.h"
#include "my_list.h"
#include "my_hash.h"
#include "my_bitmap.h"

#define LIST 0
#define HASH 1
#define BIT 2
void	init_data()
{
	int i;

	i = -1;
	while (++i < 10)
	{
		g_hash_data[i].link = NULL;
		strcpy(g_hash_data[i].name, "\0");
		g_list_data[i].link = NULL;
		strcpy(g_list_data[i].name, "\0");
		g_bitmap_data[i].link = NULL;
		strcpy(g_bitmap_data[i].name, "\0");
	}
}

int	match_type(char	*name)
{
	for (int i = 0; i < 10; i++)
	{
		if (!strcmp(name, g_list_data[i].name))
			return (LIST);
		if (!strcmp(name, g_hash_data[i].name))
			return (HASH);
		if (!strcmp(name, g_bitmap_data[i].name))
			return (BIT);
	}
	return (-1);
}
int main()
{
	init_data();
	int data_type;
	while (1)
	{
    char input[50];
    char **str;
    fgets(input, 50, stdin);
    str = ft_split(input,' ');
    if (!strcmp(str[0], "create"))
	{
		if (!strcmp(str[1], "list"))
			create_list(str[2]);
		if (!strcmp(str[1], "hashtable"))
			create_hash(str[2]);
		if (!strcmp(str[1], "bitmap"))
			create_bitmap(str[2], atoi(str[3]));
	}
	else if (!strcmp(str[0], "dumpdata"))
	{
		if ((data_type = match_type(str[1])) < 0)
			printf("There is not data\n");
		else if (data_type == LIST)
			dump_list(str[1]);
		else if (data_type == HASH)
			dump_hash(str[1]);
		else if (data_type == BIT)
			dump_bitmap(str[1]);
		else
			printf("no structure\n");
	}
	else if (!strcmp(str[0], "delete"))
	{
		if ((data_type = match_type(str[1])) < 0)
			printf("There is not data\n");
		else if (data_type == LIST)
			func_delete_list(str[1]);
		else if (data_type == HASH)	
			func_delete_hash(str[1]);
		else if (data_type == BIT)
			func_delete_bitmap(str[1]);
		else
			printf("no structure\n");
	}
	else if (!strcmp(str[0], "bitmap_mark"))
		func_bitmap_mark(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "bitmap_flip"))
		func_bitmap_flip(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "bitmap_reset"))
		func_bitmap_reset(str[1], atoi(str[2]));		
	else if (!strcmp(str[0], "bitmap_test"))
		func_bitmap_test(str[1], atoi(str[2]));	
	else if (!strcmp(str[0], "bitmap_size"))
		func_bitmap_size(str[1]);
	else if (!strcmp(str[0], "bitmap_dump"))
		func_bitmap_dump(str[1]);
	else if (!strcmp(str[0], "bitmap_all"))
		func_bitmap_all(str[1], atoi(str[2]), atoi(str[3]));
	else if (!strcmp(str[0], "bitmap_any"))
		func_bitmap_any(str[1], atoi(str[2]), atoi(str[3]));
	else if (!strcmp(str[0], "bitmap_none"))
		func_bitmap_none(str[1], atoi(str[2]), atoi(str[3]));
	else if (!strcmp(str[0], "bitmap_contains"))
		func_bitmap_contains(str[1], atoi(str[2]), atoi(str[3]), str[4]);
	else if (!strcmp(str[0], "bitmap_count"))
		func_bitmap_count(str[1], atoi(str[2]), atoi(str[3]), str[4]);
	else if (!strcmp(str[0], "bitmap_set"))
		func_bitmap_set(str[1], atoi(str[2]), str[3]);
	else if (!strcmp(str[0], "bitmap_set_multiple"))
		func_bitmap_set_multiple(str[1], atoi(str[2]), atoi(str[3]), str[4]);
	else if (!strcmp(str[0], "bitmap_scan"))
		func_bitmap_scan(str[1], atoi(str[2]), atoi(str[3]), str[4]);
	else if (!strcmp(str[0], "bitmap_scan_and_flip"))
		func_bitmap_scan_and_flip(str[1], atoi(str[2]), atoi(str[3]), str[4]);				
	else if (!strcmp(str[0], "bitmap_set_all"))
		func_bitmap_set_all(str[1], str[2]);
	else if (!strcmp(str[0], "bitmap_expand"))
		func_bitmap_expand(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "hash_insert"))
		func_hash_insert(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "hash_clear"))
		func_hash_clear(str[1]);	
	else if (!strcmp(str[0], "hash_delete"))
		func_one_delete_hash(str[1], atoi(str[2]));		
	else if (!strcmp(str[0], "hash_size"))
		func_hash_size(str[1]);
	else if (!strcmp(str[0], "hash_empty"))
		func_hash_empty(str[1]);
	else if (!strcmp(str[0], "hash_find"))
		func_hash_find(str[1], atoi(str[2]));	
	else if (!strcmp(str[0], "hash_apply"))
		func_hash_apply(str[1], str[2]);
	else if (!strcmp(str[0], "hash_replace"))
		func_hash_replace(str[1], atoi(str[2]));	
	else if (!strcmp(str[0], "list_push_front"))
		func_list_push_front_back(str[1], atoi(str[2]), FRONT);
	else if (!strcmp(str[0], "list_push_back"))
		func_list_push_front_back(str[1], atoi(str[2]), BACK);
	else if (!strcmp(str[0], "list_front"))
		func_list_front_back(str[1], FRONT);
	else if (!strcmp(str[0], "list_back"))
		func_list_front_back(str[1], BACK);
	else if (!strcmp(str[0], "list_pop_front"))
		func_list_pop_front_back(str[1], FRONT);
	else if (!strcmp(str[0], "list_pop_back"))
		func_list_pop_front_back(str[1], BACK);
	else if (!strcmp(str[0], "list_empty"))
		func_list_empty(str[1]);
	else if (!strcmp(str[0], "list_size"))
		func_list_size(str[1]);
	else if (!strcmp(str[0], "list_reverse"))
		func_list_reverse(str[1]);
	else if (!strcmp(str[0], "list_max"))
		func_list_max_min(str[1], MAX);
	else if (!strcmp(str[0], "list_min"))
		func_list_max_min(str[1], MIN);
	else if (!strcmp(str[0], "list_sort"))
		func_list_sort(str[1]);
	else if (!strcmp(str[0], "list_shuffle"))
		func_list_shuffle(str[1]);
	else if (!strcmp(str[0], "list_swap"))
		func_list_swap(str[1], atoi(str[2]), atoi(str[3]));
	else if (!strcmp(str[0], "list_unique"))
	{
		if (!str[2])
			func_list_unique_1(str[1]);
		else
			func_list_unique_2(str[1], str[2]);	
	}
	else if (!strcmp(str[0], "list_insert_ordered"))
		func_list_inserted_ordered(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "list_remove"))
		func_list_remove(str[1], atoi(str[2]));
	else if (!strcmp(str[0], "list_insert"))
		func_list_insert(str[1], atoi(str[2]), atoi(str[3]));
	else if (!strcmp(str[0], "list_splice"))
		func_list_splice(str[1], atoi(str[2]), str[3], atoi(str[4]), atoi(str[5]));
	else if (!strcmp(str[0], "quit"))
		break ;
	else
		printf("Command not found\n");
	}
    return 0;
}
