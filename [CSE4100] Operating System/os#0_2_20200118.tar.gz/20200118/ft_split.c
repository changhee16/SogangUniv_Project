#include "ft_split.h"

int	ft_count(char const *s, char c)
{
	int	cnt;

	cnt = 0;
	while (*s)
	{
		if (*s == c)
			s++;
		else
		{
			cnt++;
			while (*s && *s != c)
				s++;
		}
	}
	return (cnt);
}

char	*ft_strndup(const char *s, int n)
{
	int		i;
	char	*str;

	i = 0;
	str = (char *)malloc(n + 1);
	while (i < n)
	{
		str[i] = s[i];
		i++;
	}
	str[i] = 0;
	return (str);
}

char	**ft_free(char **split)
{
	int	i;

	i = 0;
	while (split[i])
	{
		free(split[i]);
		i++;
	}
	free(split);
	return (split);
}

char	**ft_split(char const *s, char c)
{
	char	**split;
	int		i;
	int		count;
	int		tmp;

	i = 0;
	count = 0;
	split = (char **)malloc(sizeof(char *) * (ft_count(s, c) + 1));
	while (count < ft_count(s, c) && s[i])
	{
		while (s[i] == c)
			i++;
		tmp = i;
		while (s[i] != c && s[i])
			i++;
		if (!s[i]) //임시방편..
			i--;
		split[count] = ft_strndup(&s[tmp], i - tmp);
		if (!split[count])
			return (ft_free(split));
		count++;
	}
	split[count] = NULL;
	return (split);
}
