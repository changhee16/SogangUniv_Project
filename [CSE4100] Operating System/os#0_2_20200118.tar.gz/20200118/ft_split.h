#ifndef __FT_SPLIT_H
#define __FT_SPLIT_H

#include <stdlib.h>

int	ft_count(char const *s, char c);
char	*ft_strndup(const char *s, int n);
char	**ft_free(char **split);
char	**ft_split(char const *s, char c);

#endif