
#include "my_list.h"

int	match_list_index(char	*name)
{
	int list_index;

	list_index = -1;

	while (++list_index < 10)
	{
		if (!strcmp(g_list_data[list_index].name, name))
		{
			return (list_index);
		}
	}
	return (-1);
}

int check_null_list()
{
	int i;

	i = -1;
	while (++i < 10)
	{
		if (!g_list_data[i].link)//strcmp(g_list_data[i].name, "\0"))
			break;
	}
	return (i);
}

void	create_list(char	*name)
{
	int list_index;

	if ((list_index = check_null_list()) < 0)
		return ;
	strcpy(g_list_data[list_index].name, name);
	g_list_data[list_index].link = (struct list*)malloc(sizeof(struct list));
	list_init(g_list_data[list_index].link);
}

void	dump_list(char	*name)
{
	struct list_elem *e;
	struct list_item *tmp;
	int list_index;

	if ((list_index = match_list_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}
	e = list_begin(g_list_data[list_index].link);

	while (e != list_end(g_list_data[list_index].link))
	{
		tmp = list_entry(e, struct list_item, elem);
		printf("%d ", tmp->data);
		e = list_next(e);
	}
	printf("\n");
}

void	func_list_front_back(char *name, int flag)
{
	int list_index;
	struct list_elem *e;
	struct list_item *tmp;

	if ((list_index = match_list_index(name)) < 0)
		return ;
	if (flag == FRONT)
		e = list_begin(g_list_data[list_index].link);
	else if (flag == BACK)
		e = list_back(g_list_data[list_index].link);
	tmp = list_entry(e, struct list_item, elem);
    printf("%d\n", tmp -> data);
}

void	func_list_pop_front_back(char	*name, int flag)
{
	int list_index;
	struct list_elem *e;
	struct list_item *tmp;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	if (flag == FRONT)
		e = list_pop_front(g_list_data[list_index].link);
	else if (flag == BACK)
		e = list_pop_back(g_list_data[list_index].link);
	tmp = list_entry(e, struct list_item, elem);
	free(tmp);
	tmp = NULL;
}

void	func_list_remove(char	*name, int	index)
{
	int list_index;
	struct list_elem *e;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	e = list_begin(g_list_data[list_index].link);
	for (int i = 0; i < index; i++)
		e = list_next(e);
	list_remove(e);
}

void	func_list_push_front_back(char	*name, int num, int flag)
{
	int list_index;
	struct list_item *node;

	list_index = match_list_index(name);
	if (list_index < 0)
	{
		printf("There is not node\n");
		return ;
	}
	node = (struct list_item *)malloc(sizeof(struct list_item));
	node -> data = num;
	if (flag == BACK)
		list_push_back(g_list_data[list_index].link, &(node -> elem));
	else
		list_push_front(g_list_data[list_index].link, &(node -> elem));
}

void	func_list_empty(char	*name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	if (list_empty(g_list_data[list_index].link))
		printf("true\n");
	else
		printf("false\n");
}

void	func_list_size(char		*name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	printf("%zu\n", list_size(g_list_data[list_index].link));	
}

void	func_list_max_min(char		*name, int flag)
{
	int list_index;
	struct list_elem *e;
	struct list_item *tmp;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	if (flag == MAX)
		e = list_max(g_list_data[list_index].link, func_list_less, NULL);
	else
		e = list_min(g_list_data[list_index].link, func_list_less, NULL);
	tmp = list_entry(e, struct list_item, elem);
	printf("%d\n", tmp->data);
}


void	func_delete_list(char	*name)
{
	int list_index;
	struct list_elem *e;
	struct list_item *tmp;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	g_list_data[list_index].name[0] = '\0';
	e = list_begin(g_list_data[list_index].link);
	while (e != list_end(g_list_data[list_index].link))
		e = list_remove(e);
	free(g_list_data[list_index].link);
	g_list_data[list_index].link = NULL;
}

void	func_list_reverse(char *name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	list_reverse(g_list_data[list_index].link);	
}

void	func_list_inserted_ordered(char	*name, int data)
{
	int list_index;
	struct list_item *node;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	node = (struct list_item *)malloc(sizeof(struct list_item));
	node -> data = data;
	list_insert_ordered(g_list_data[list_index].link, &(node -> elem), func_list_less, NULL);
}

void	func_list_sort(char	*name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	list_sort(g_list_data[list_index].link, func_list_less, NULL);	
}

void	func_list_swap(char	*name, int a, int b)
{
	int list_index;
	struct list_elem	*e_1;
	struct list_elem	*e_2;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	e_1 = list_begin(g_list_data[list_index].link);
	for (int i = 0; i < a; i++)
		e_1 = list_next(e_1);
	e_2 = list_begin(g_list_data[list_index].link);
	for (int i = 0; i < b; i++)
		e_2 = list_next(e_2);	
	list_swap(e_1, e_2);
}

void	func_list_shuffle(char	*name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	list_shuffle(g_list_data[list_index].link);
}

void	func_list_unique_1(char	*name)
{
	int list_index;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	list_unique(g_list_data[list_index].link, NULL, func_list_less, NULL);
}

void	func_list_unique_2(char	*name_1, char	*name_2)
{
	int list_index_1;
	int list_index_2;

	list_index_1 = match_list_index(name_1);
	list_index_2 = match_list_index(name_2);
	
	if (list_index_1 < 0 || list_index_2 < 0)
		return ;
	list_unique(g_list_data[list_index_1].link, g_list_data[list_index_2].link, func_list_less, NULL);
}

void	func_list_insert(char	*name, int index, int data)
{
	int list_index;
	struct list_item	*node;
	struct list_elem	*e;

	list_index = match_list_index(name);
	if (list_index < 0)
		return ;
	node = (struct list_item *)malloc(sizeof(struct list_item));
	node -> data = data;

	e = list_begin(g_list_data[list_index].link);
	for (int i = 0; i < index; i++)
		e = list_next(e);
	list_insert(e, &(node -> elem));
}

void    func_list_splice(char   *name_1, int index_1, char	*name_2, int start, int end)
{
	int list_index_1;
	int	list_index_2;
	struct	list_elem	*before;
	struct	list_elem	*first;
	struct	list_elem	*last;

	list_index_1 = match_list_index(name_1);
	list_index_2 = match_list_index(name_2);	
	if (list_index_1 < 0 || list_index_2 < 0)
		return ;
	before = list_begin(g_list_data[list_index_1].link);
	first = list_begin(g_list_data[list_index_2].link);
	last = list_begin(g_list_data[list_index_2].link);

	for (int i = 0; i < index_1; i++)
		before = list_next(before);
	for (int i = 0; i < start; i++)
		first = list_next(first);
	for (int i = 0; i < end; i++)
		last = list_next(last);
	list_splice (before, first, last);
}