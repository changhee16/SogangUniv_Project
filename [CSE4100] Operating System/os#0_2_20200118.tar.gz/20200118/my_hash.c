#include "my_hash.h"

int check_null_hash()
{
	int i;

	i = -1;
	while (++i < 10)
	{
		if (!g_hash_data[i].link)
			break;
	}
	return (i);
}

int	match_hash_index(char	*name)
{
	int hash_index;

	hash_index = -1;

	while (++hash_index < 10)
	{
		if (!strcmp(g_hash_data[hash_index].name, name))
		{
			return (hash_index);
		}
	}
	return (-1);
}

void	dump_hash(char	*name)
{
	struct hash_iterator i;
	struct hash *hash_table;
    struct hash_item    *tmp;
	int hash_index;

	if ((hash_index = match_hash_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}

    hash_table = g_hash_data[hash_index].link;
	hash_first(&i, hash_table);
	while (hash_next(&i))
	{
		tmp = hash_entry(i.elem, struct hash_item, elem);
		printf("%d ", tmp->data);
	}
	printf("\n");
}

void	create_hash(char	*name)
{
	int hash_index;

	if ((hash_index = check_null_hash()) < 0)
		return ;
	strcpy(g_hash_data[hash_index].name, name);
	g_hash_data[hash_index].link = (struct hash*)malloc(sizeof(struct hash));
	hash_init(g_hash_data[hash_index].link, func_hash_func, func_hash_less, NULL);
}

void	func_hash_insert(char	*name, int data)
{
	int	hash_index;
	struct hash_item	*new;
	if ((hash_index = match_hash_index(name)) < 0)
	{
		printf("Error: There is no index\n");
		return ;
	}	
	new = (struct hash_item *)malloc(sizeof(struct hash_item));
	new -> data = data;
	hash_insert(g_hash_data[hash_index].link, &(new -> elem));
}

void	func_hash_size(char	*name)
{
	int hash_index;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	printf("%zu\n", hash_size(g_hash_data[hash_index].link));		
}

void	func_hash_empty(char	*name)
{
	int hash_index;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	if (hash_empty(g_hash_data[hash_index].link))
		printf("true\n");
	else
		printf("false\n");
}

void	func_hash_clear(char	*name)
{
	int hash_index;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	hash_clear(g_hash_data[hash_index].link, NULL);		
}

void	func_delete_hash(char	*name)
{
	int hash_index;
	struct hash_iterator i;
	struct hash *hash_table;
	struct hash_elem	*e;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	hash_table = g_hash_data[hash_index].link;
	hash_first(&i, hash_table);
	while (hash_next(&i))
		e = hash_delete(hash_table, hash_cur(&i));
	free(g_hash_data[hash_index].link);
	g_hash_data[hash_index].link = NULL;
	g_hash_data[hash_index].name[0] = '\0';
}

void	func_one_delete_hash(char	*name, int data)
{
	int hash_index;
	struct hash_item	tmp;
	struct hash_elem	*find;
	struct hash_item	*del;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	tmp.data = data;
	if (find = hash_find(g_hash_data[hash_index].link, &(tmp.elem)))
	{
		del = hash_entry(find, struct hash_item, elem);
		hash_delete(g_hash_data[hash_index].link, find);
		free(del);
	}
}

void	func_hash_find(char	*name, int data)
{
	int hash_index;
	struct hash_item	tmp;
	struct hash_elem	*find;
	struct hash_item	*target;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	tmp.data = data;
	if (find = hash_find(g_hash_data[hash_index].link, &(tmp.elem)))
	{
		target = hash_entry(find, struct hash_item, elem);
		printf("%d\n", target->data);
	}
}

void	func_hash_apply(char	*name, char	*func)
{
	int hash_index;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;	
	if(!strcmp(func, "square")){
		hash_apply(g_hash_data[hash_index].link, func_square);
	}
	else if(!strcmp(func, "triple")){
		hash_apply(g_hash_data[hash_index].link, func_triple);
	}
}

void	func_hash_replace(char	*name, int data)
{
	int hash_index;
	struct hash_item	*tmp;

	hash_index = match_hash_index(name);
	if (hash_index < 0)
		return ;
	tmp = (struct hash_item	*)malloc(sizeof(struct hash_item));
	tmp -> data = data;
	hash_replace(g_hash_data[hash_index].link, &(tmp -> elem));
}